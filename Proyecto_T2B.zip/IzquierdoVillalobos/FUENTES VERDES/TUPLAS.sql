-----------------------------------
        /*CICLO 1: Tuplas*/
-----------------------------------
/*ADICION*/

--El precio_max debe ser mayor al precio_min. (CK_precio_min_max)
ALTER TABLE solicitud ADD CONSTRAINT CK_precio_min_max CHECK (precio_max > precio_min);

INSERT INTO participante VALUES ('CC',1075689856,'COM','Lina','Izquierdo','laliuta@mail.com');
INSERT INTO factormatch VALUES (154,'PROCESO');
--TuplasOK--
INSERT INTO solicitud VALUES (154,'CC',1075689856,'COM',TO_DATE('2018/01/03','yyyy/mm/dd'),18000000,22000000);

--TuplasNoOK--
INSERT INTO solicitud VALUES (154,'CC',1075689856,'COM',TO_DATE('2018/01/03','yyyy/mm/dd'),180000000,22000000);

-------------------------------------
       /*CICLO 1: Disparadores*/ 
-------------------------------------
----------MANTENER SOLICITUD----------

/*ADICION*/

--El número y la fecha se asigna automáticamente. (TG_auto)
CREATE OR REPLACE TRIGGER TG_auto
BEFORE INSERT ON factorMatch
FOR EACH ROW
DECLARE
N NUMBER;
E VARCHAR(7);
BEGIN
    N := 0;
    SELECT COUNT(*)+1 INTO N FROM factorMatch;
    :new.codigo := N;
    
    E := 'PROCESO';
    :new.estado := E;
    
END TG_auto;

--El estado se asigna automáticamente. (TG_auto_fecha)
CREATE OR REPLACE TRIGGER TG_auto_fecha
BEFORE INSERT ON solicitud
FOR EACH ROW
DECLARE
F DATE;
BEGIN
    
    F := TO_DATE(SYSDATE,'YYYY-MM-DD');
    :new.fecha := F;

END TG_auto_fecha;

--DisparadoresOK--
INSERT INTO participante VALUES ('CC',1075689854,'COM','Lina','Izquierdo','laxlita@mail.com');
INSERT INTO factormatch (codigo) VALUES (123);
INSERT INTO solicitud (numero,tid,nid,tipo,precio_min,precio_max) VALUES (3,'CC',1075689854,'COM',15000000,28000000);

--DisparadoresNoOK--
/*N.A*/

--XDisparador
DROP TRIGGER TG_auto;
DROP TRIGGER TG_auto_fecha;


/*MODIFICACION*/
--No esta permitido modificar los datos de identificacion del comprador, excepto telefono. (AC_identificacion)
CREATE OR REPLACE TRIGGER TG_mod_info
BEFORE UPDATE ON participante
FOR EACH ROW
BEGIN
  IF :new.tid <> :old.tid or :new.nid<> :old.nid or :new.nombre<>:old.nombre or :new.apellido<> :old.apellido or :new.email<> :old.email THEN
    :new.tid:=:old.tid; 
    :new.nid:= :old.nid;
    :new.nombre:=:old.nombre;
    :new.apellido:= :old.apellido;
    :new.email:= :old.email;
  END IF;    
END TG_mod_info;

INSERT INTO participante VALUES ('NT',2158363,'COM','Alejandra','Muñoz','muñroz@mail.com');
INSERT INTO factormatch VALUES (8,'PROCESO');
INSERT INTO solicitud VALUES (8,'NT',2158363,'COM',TO_DATE('2018/08/23','yyyy/mm/dd'),NULL,52000000);

--DisparadoresOK--
UPDATE participante SET nombre= 'Alejandra' WHERE tid= 'CC';

--DisparadoresNoOK--
/*N.A*/

--XDisparador
DROP TRIGGER TG_mod_info;

--Los únicos datos a modificar son: telefono si no se ingresó al momento de adición y estado si pasados 180 dias no entra en 'ENMATCH' pasa a 'CERRADA'. (TG_telefono) (TG_estado)

/*ELIMINACION*/
--Los participantes siempre se pueden eliminar, si no tienen solicitudes.
CREATE OR REPLACE TRIGGER TG_elimina_par
BEFORE DELETE ON participante
FOR EACH ROW
DECLARE
Sol NUMBER ;
BEGIN
    SELECT COUNT(*) INTO Sol FROM solicitud WHERE :old.nid = nid;
    IF Sol > 0 THEN
      raise_application_error(-20004,'No se puede eliminar');
    END IF;
END TG_elimina_par;

INSERT INTO participante VALUES ('NT',21583,'COM','Alejandra','Muñoz','muroz@mail.com');
--DisparadoresOK--
DELETE FROM participante WHERE nid= 21583;
--DisparadoresNoOK--
/*N.A*/

--XDisparador
DROP TRIGGER TG_elimina_par;

--Es posible eliminar la solicitud si su estado es 'CERRADA' (TG_estado_solicitud)
CREATE OR REPLACE TRIGGER TG_estado_solicitud
BEFORE INSERT ON factorMatch
FOR EACH ROW
DECLARE
Testado VARCHAR;
BEGIN

    SELECT estado INTO Testado FROM factorMatch
    WHERE estado = 'CERRADA';
    :new.estado := Testado;

END TG_estado_solicitud;

--DisparadoresOK--
DELETE FROM factorMatch WHERE codigo = 108 ;
--DisparadoresNoOK--
/*N.A*/

--XDisparador
DROP TRIGGER TG_estado_solicitud;

--Las solicitudes se deben poder eliminar si no tienen al menos 5 factorMatch (area, condicion, inmueble, tipoPiso, ubicacion, estrato, tipoOferta, antiguedad, habitacion) (TG_factorMatch)


----------MANTENER OFERTA----------

/*ADICION*/

--El numero y la fecha  se asigna automAticamente.
CREATE OR REPLACE TRIGGER numero_fecha_automaticos 
BEFORE INSERT ON OFERTA
FOR EACH ROW
DECLARE 
contador NUMBER(4);
fech DATE;
BEGIN
    SELECT MAX(numero)+1 INTO contador FROM oferta;
    SELECT SYSDATE() INTO fech FROM oferta;
    :NEW.fecha:=fech;
    :NEW.numero:=contador;
END numero_fecha_automaticos;

--El estado se asigna automaticamente.
CREATE OR REPLACE TRIGGER estado 
BEFORE INSERT ON factorMatch
FOR EACH ROW
BEGIN
    :NEW.estado:='PROCESO';
END estado;

--DisparadoresOK--
INSERT INTO participante VALUES ('CC',1075689854,'COM','Lina','Izquierdo','laxlita@mail.com');
INSERT INTO factormatch (codigo) VALUES (123);
INSERT INTO solicitud (numero,tid,nid,tipo,precio_min,precio_max) VALUES (3,'CC',1075689854,'COM',15000000,28000000);

INSERT INTO factormatch VALUES (108,'CERRADO');

--DisparadoresNoOK--
/*N.A*/

--XDisparador
DROP TRIGGER numero_fecha_automaticos;
DROP TRIGGER estado;

--El participante que hace la oferta debe ser tipo vendedor.
CREATE OR REPLACE TRIGGER tipo_vendedor 
AFTER INSERT ON OFERTA
FOR EACH ROW 
BEGIN
    IF :NEW.tipo!='VEN' THEN
    RAISE_APPLICATION_ERROR(-20003,'Solo se puede ser de tipo vendedor');
    END IF;
END tipo_vendedor;

--DisparadoresOK--
INSERT INTO oferta VALUES (108,'NT',2158333,'VEN',TO_DATE('2018/07/03','yyyy/mm/dd'),100000000,1);

--DisparadoresNoOK--
/*N.A*/

--XDisparador
DROP TRIGGER tipo_vendedor;

--Si el participante que hace la oferta fue tambien comprador, debe tener un numero distinto al numero de solicitudes hechas.
CREATE OR REPLACE TRIGGER COMPRADOR_VENDEDOR_NUMERO
AFTER INSERT ON OFERTA
FOR EACH ROW
DECLARE
soli NUMBER(5);
BEGIN
    SELECT numero INTO soli 
    FROM solicitud WHERE numero=:NEW.numero;
    IF soli IS NULL THEN
    RAISE_APPLICATION_ERROR(-20003,' el participante que hace la oferta  fue tambien comprador, debe tener un numero distinto al numero de solicitudes hechas.');
    END IF;
END COMPRADOR_VENDEDOR_NUMERO;

--DisparadoresOK--
INSERT INTO factormatch VALUES (110,'PROCESO');
INSERT INTO oferta VALUES (109,'CC',35416363,'VEN',TO_DATE('2018/01/03','yyyy/mm/dd'),25000000,1);

--DisparadoresNoOK--
/*N.A*/

--XDisparador
DROP TRIGGER COMPRADOR_VENDEDOR_NUMERO;

--El precioOferta puede cambiar, si y solo si negociable es 1.
--La fecha de las actualizaciones  se inserta automaticamente
CREATE OR REPLACE TRIGGER fechas_actualizacion
BEFORE INSERT ON actualizacion
FOR EACH ROW
DECLARE
fechas DATE;
BEGIN
    SELECT SYSDATE() INTO fechas FROM oferta;
    :NEW.ultima_actualizacion:=fechas;
END fechas_actualizacion;

--DisparadoresOK--
INSERT INTO actualizacion VALUES (100,TO_DATE('2018/01/06','yyyy/mm/dd'));

--DisparadoresNoOK--
/*N.A*/

--XDisparador
DROP TRIGGER fechas_actualizacion;


/*MODIFICACION*/

---No esta permitido modificar los datos de identificacion del vendedor, excepto telefono.
CREATE OR REPLACE TRIGGER telefono
AFTER UPDATE ON OFERTA
FOR EACH ROW
BEGIN
    RAISE_APPLICATION_ERROR(-20003,'No esta permitido modificar los datos de identificacion del vendedor, excepto telefono.');
END telefono;

--DisparadoresOK--
UPDATE telefono set numero='12345678' WHERE numero='3118104371';
DROP trigger telefono;
--DisparadoresNoOK--
/*N.A*/

--XDisparador
DROP trigger telefono;

--si pasados 30 dias no entra en 'ENMATCH' pasa el estado a 'CERRADA'.
/*CREATE OR REPLACE TRIGGER match_cerrado
BEFORE UPDATE ON factorMatch
FOR EACH ROW
BEGIN
    
END;*/
--No esta permitido modificar los datos de identificacion del vendedor, excepto telefono.

/*ELIMINACION*/

--Los vendedores se deben de poder eliminar si no tienen ofertas asociadas.
CREATE OR REPLACE TRIGGER vendedores_eliminacion
BEFORE DELETE ON participante 
FOR EACH ROW
DECLARE
revisar NUMBER(3);
BEGIN
    SELECT COUNT(numero) INTO revisar FROM oferta WHERE nid=:OLD.nid AND tid=:OLD.tid;
    IF revisar > 0 AND :OLD.tipo='VEN' THEN
    RAISE_APPLICATION_ERROR(-20005,'Los vendedores se deben de poder eliminar si no tienen ofertas');
    END IF;
END vendedores_eliminacion;

--DisparadoresOK--
DELETE FROM  factormatch WHERE codigo=115;

--DisparadoresNoOK--
DELETE FROM  factormatch WHERE codigo=100;

--XDisparador
DROP TRIGGER vendedores_eliminacion;
 
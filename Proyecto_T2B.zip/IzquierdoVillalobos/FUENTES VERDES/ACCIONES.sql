-----------------------------------
       /*CICLO 1: Acciones*/
-----------------------------------
/*MODIFICACION*/

--Los compradores se deben de poder eliminar si no tienen solicitudes asociadas. (AC_elimina_solicitud)
ALTER TABLE solicitud DROP CONSTRAINT FK_solicitud_participante;
ALTER TABLE solicitud ADD CONSTRAINT FK_solicitud_participante
FOREIGN KEY (tid,nid,tipo) REFERENCES participante (tid,nid,tipo) ON DELETE CASCADE;

INSERT INTO participante VALUES ('CC',1075689856,'COM','Lina','Izquierdo','laliuta@mail.com');
INSERT INTO factormatch VALUES (154,'PROCESO');
INSERT INTO solicitud VALUES (154,'CC',1075689856,'COM',TO_DATE('2018/01/03','yyyy/mm/dd'),18000000,22000000);

--AccionesOK--
DELETE FROM solicitud WHERE tid = 'CC' AND nid = 1075689856 AND tipo = 'COM';

-----------------------------------------------------------------
                       /*CICLO 1: Foraneas*/
-----------------------------------------------------------------

--telefono-participante
ALTER TABLE telefono ADD CONSTRAINT FK_telefono_participante FOREIGN KEY (tid,nid,tipo) REFERENCES participante (tid,nid,tipo);
--solicitud-participante
ALTER TABLE solicitud ADD CONSTRAINT FK_solicitud_participante FOREIGN KEY (tid,nid,tipo) REFERENCES participante (tid,nid,tipo);
--oferta-participante
ALTER TABLE oferta ADD CONSTRAINT FK_oferta_participante FOREIGN KEY (tid,nid,tipo) REFERENCES participante (tid,nid,tipo);
--actualizacion-oferta
ALTER TABLE actualizacion ADD CONSTRAINT FK_actualizacion_oferta
FOREIGN KEY (numero) REFERENCES oferta (numero);

--solicitud-factorMatch
ALTER TABLE solicitud ADD CONSTRAINT FK_solicitud_factorMatch FOREIGN KEY (numero) REFERENCES factorMatch (codigo);
--oferta-factorMatch
ALTER TABLE oferta ADD CONSTRAINT FK_oferta_factorMatch FOREIGN KEY (numero) REFERENCES factorMatch (codigo);

--area-factorMatch
ALTER TABLE area ADD CONSTRAINT FK_area_factorMatch FOREIGN KEY (codigo) REFERENCES factorMatch (codigo);
--estrato-factorMatch
ALTER TABLE estrato ADD CONSTRAINT FK_estrato_factorMatch FOREIGN KEY (codigo) REFERENCES factorMatch (codigo);
--inmueble-factorMatch
ALTER TABLE inmueble ADD CONSTRAINT FK_inmueble_factorMatch FOREIGN KEY (codigo) REFERENCES factorMatch (codigo);
--ubicacion-factorMatch
ALTER TABLE ubicacion ADD CONSTRAINT FK_ubicacion_factorMatch FOREIGN KEY (codigo) REFERENCES factorMatch (codigo);
--antiguedad-factorMatch
ALTER TABLE antiguedad ADD CONSTRAINT FK_antiguedad_factorMatch FOREIGN KEY (codigo) REFERENCES factorMatch (codigo);
--tipoOferta-factorMatch
ALTER TABLE tipoOferta ADD CONSTRAINT FK_tipoOferta_factorMatch FOREIGN KEY (codigo) REFERENCES factorMatch (codigo);
--habitacion-factorMatch
ALTER TABLE habitacion ADD CONSTRAINT FK_habitacion_factorMatch FOREIGN KEY (codigo) REFERENCES factorMatch (codigo);
--tipoPiso-factorMatch
ALTER TABLE tipoPiso ADD CONSTRAINT FK_tipoPiso_factorMatch FOREIGN KEY (codigo) REFERENCES factorMatch (codigo);
--condicion-factorMatch
ALTER TABLE condicion ADD CONSTRAINT FK_condicion_factorMatch FOREIGN KEY (codigo) REFERENCES factorMatch (codigo);
--extra-factorMatch
ALTER TABLE extra ADD CONSTRAINT FK_extra_factorMatch FOREIGN KEY (codigo) REFERENCES factorMatch (codigo);
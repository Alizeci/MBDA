------------------------------------------------------------------------------------------------------------
                                          /*CICLO 1: PoblarOK*/
------------------------------------------------------------------------------------------------------------

INSERT INTO participante VALUES ('CC',1075689856,'COM','Lina','Izquierdo','lalita@mail.com');
INSERT INTO participante VALUES ('CC',35416363,'VEN','Luz','Castro','lucecita@mail.com');
INSERT INTO participante VALUES ('CC',1073254906,'COM','Juliet','Villalobos','villalobos@mail.com');
INSERT INTO participante VALUES ('NT',2158331,'VEN','Fernando','Siervo','siervo@mail.com');
INSERT INTO participante VALUES ('CC',1073254907,'COM','Yarit','Jimenez','jimenez@mail.com');
INSERT INTO participante VALUES ('NT',2158332,'VEN','Yajanny','Velandia','velandia@mail.com');
INSERT INTO participante VALUES ('CC',1073254908,'COM','Laura','Chavarro','laura@mail.com');
INSERT INTO participante VALUES ('NT',2158333,'VEN','Alejandra','Muñoz','muñoz@mail.com');

INSERT INTO telefono VALUES ('CC',1075689856,'COM',3118104371);
INSERT INTO telefono VALUES ('CC',35416363,'VEN',3123590373);
INSERT INTO telefono VALUES ('CC',1073254906,'COM',3042138635);
INSERT INTO telefono VALUES ('NT',2158331,'VEN',3042138636);
INSERT INTO telefono VALUES ('CC',1073254907,'COM',3042138637);
INSERT INTO telefono VALUES ('NT',2158332,'VEN',3042138638);
INSERT INTO telefono VALUES ('CC',1073254908,'COM',3042138639);
INSERT INTO telefono VALUES ('NT',2158333,'VEN',3042138640);
INSERT INTO telefono VALUES ('CC',1075689856,'COM',3118104372);

INSERT INTO factormatch VALUES (100,'PROCESO');
INSERT INTO factormatch VALUES (101,'PROCESO');
INSERT INTO factormatch VALUES (102,'PROCESO');
INSERT INTO factormatch VALUES (105,'PROCESO');
INSERT INTO factormatch VALUES (104,'PROCESO');
INSERT INTO factormatch VALUES (103,'PROCESO');
INSERT INTO factormatch VALUES (106,'PROCESO');
INSERT INTO factormatch VALUES (107,'PROCESO');

INSERT INTO oferta VALUES (100,'CC',35416363,'VEN',TO_DATE('2018/01/03','yyyy/mm/dd'),25000000,1);
INSERT INTO solicitud VALUES (101,'CC',1075689856,'COM',TO_DATE('2018/01/03','yyyy/mm/dd'),18000000,22000000);
INSERT INTO oferta VALUES (102,'NT',2158331,'VEN',TO_DATE('2016/11/23','yyyy/mm/dd'),35500000,0);
INSERT INTO solicitud VALUES (105,'CC',1073254906,'COM',TO_DATE('2009/06/13','yyyy/mm/dd'),23400000,28000000);
INSERT INTO oferta VALUES (104,'NT',2158332,'VEN',TO_DATE('2018/01/03','yyyy/mm/dd'),15300000,0);
INSERT INTO solicitud VALUES (103,'CC',1073254907,'COM',TO_DATE('2018/06/13','yyyy/mm/dd'),22700000,36200000);
INSERT INTO oferta VALUES (106,'NT',2158333,'VEN',TO_DATE('2018/07/03','yyyy/mm/dd'),100000000,1);
INSERT INTO solicitud VALUES (107,'CC',1073254908,'COM',TO_DATE('2018/08/23','yyyy/mm/dd'),NULL,52000000);

INSERT INTO actualizacion VALUES (100,TO_DATE('2018/01/06','yyyy/mm/dd'));
INSERT INTO actualizacion VALUES (102,TO_DATE('2018/01/04','yyyy/mm/dd'));
INSERT INTO actualizacion VALUES (104,TO_DATE('2018/03/15','yyyy/mm/dd'));

INSERT INTO area VALUES(100,70.2,54.6);
INSERT INTO area VALUES(101,70.0,45.5);
INSERT INTO area VALUES(102,54.4,NULL);
INSERT INTO area VALUES(104,47.8,38.3);
INSERT INTO area VALUES(106,97.56,34.3);
INSERT INTO area VALUES(103,57.4,NULL);
INSERT INTO area VALUES(105,40.4,32.22);
INSERT INTO area VALUES(107,55.4,31.1);

INSERT INTO estrato VALUES(100,3);
INSERT INTO estrato VALUES(101,3);
INSERT INTO estrato VALUES(102,3);
INSERT INTO estrato VALUES(104,3);
INSERT INTO estrato VALUES(106,2);
INSERT INTO estrato VALUES(103,3);
INSERT INTO estrato VALUES(105,2);
INSERT INTO estrato VALUES(107,5);

INSERT INTO inmueble VALUES(100,'Casa','Amplia Casa');
INSERT INTO inmueble VALUES(101,'Casa',null);
INSERT INTO inmueble VALUES(102,'Casa',null);
INSERT INTO inmueble VALUES(104,'Casa',null);
INSERT INTO inmueble VALUES(106,'Industrial',null);
INSERT INTO inmueble VALUES(103,'Casa',null);
INSERT INTO inmueble VALUES(105,'Local',null);
INSERT INTO inmueble VALUES(107,'Casa',null);

INSERT INTO ubicacion VALUES(100,'Cundinamarca','Bogotá','Norte',null);
INSERT INTO ubicacion VALUES(101,'Cundinamarca','Bogotá','Norte',null);
INSERT INTO ubicacion VALUES(102,'Boyaca','Tunja','sur',Null);
INSERT INTO ubicacion VALUES(104,'Cundinamarca','Mosquera','norte','Alicante');
INSERT INTO ubicacion VALUES(106,'Cundinamarca','Zipaquira','sur',NULL);
INSERT INTO ubicacion VALUES(103,'Boyaca','Tunja','sur',Null);
INSERT INTO ubicacion VALUES(105,'Cundinamarca','Mosquera','norte','Alicante');
INSERT INTO ubicacion VALUES(107,'Cundinamarca','Chía','sur',NULL);

INSERT INTO antiguedad VALUES(100,NULL);
INSERT INTO antiguedad VALUES(101,'A1');
INSERT INTO antiguedad VALUES(102,NULL);
INSERT INTO antiguedad VALUES(104,'A2');
INSERT INTO antiguedad VALUES(106,'A1');
INSERT INTO antiguedad VALUES(103,NULL);
INSERT INTO antiguedad VALUES(105,'A2');
INSERT INTO antiguedad VALUES(107,'A1');

INSERT INTO tipoOferta VALUES(100,'V');
INSERT INTO tipoOferta VALUES(101,'V');
INSERT INTO tipoOferta VALUES(102,'A');
INSERT INTO tipoOferta VALUES(104,'A');
INSERT INTO tipoOferta VALUES(106,'V');
INSERT INTO tipoOferta VALUES(103,'A');
INSERT INTO tipoOferta VALUES(105,'V');
INSERT INTO tipoOferta VALUES(107,'A');

INSERT INTO habitacion VALUES(100,4,NULL);
INSERT INTO habitacion VALUES(101,5,2);
INSERT INTO habitacion VALUES(102,2,1);
INSERT INTO habitacion VALUES(104,4,2);
INSERT INTO habitacion VALUES(106,0,NULL);
INSERT INTO habitacion VALUES(103,2,NULL);
INSERT INTO habitacion VALUES(105,0,NULL);
INSERT INTO habitacion VALUES(107,2,1);

INSERT INTO tipoPiso VALUES(100,'P1',3,null);
INSERT INTO tipoPiso VALUES(101,'P4',3,null);
INSERT INTO tipoPiso VALUES(102,'P1',2,'limpio y bonito');
INSERT INTO tipoPiso VALUES(104,'P2',2,NULL);
INSERT INTO tipoPiso VALUES(106,'P5',1,NULL);
INSERT INTO tipoPiso VALUES(103,'P1',2,'limpio');
INSERT INTO tipoPiso VALUES(105,'P5',2,NULL);
INSERT INTO tipoPiso VALUES(107,'P1',3,NULL);

INSERT INTO condicion VALUES(100,'NUEVO');
INSERT INTO condicion VALUES(101,'USADO');
INSERT INTO condicion VALUES(102,'NUEVO');
INSERT INTO condicion VALUES(104,'NUEVO');
INSERT INTO condicion VALUES(106,'USADO');
INSERT INTO condicion VALUES(103,'NUEVO');
INSERT INTO condicion VALUES(105,'NUEVO');
INSERT INTO condicion VALUES(107,'USADO');

INSERT INTO extra VALUES(100,'Con jardín');
INSERT INTO extra VALUES(101,'Con jardín');
INSERT INTO extra VALUES(104,'Con parqueadero');
INSERT INTO extra VALUES(102,null);
INSERT INTO extra VALUES(106,'Zona descargue');
INSERT INTO extra VALUES(103,'Minibar');
INSERT INTO extra VALUES(105,null);
INSERT INTO extra VALUES(107,'Zona deporte');
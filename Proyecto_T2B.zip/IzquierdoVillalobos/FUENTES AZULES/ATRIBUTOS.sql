---------------------------------------
        /*CICLO 1: Atributos*/
---------------------------------------
--TCodigo
ALTER TABLE factorMatch MODIFY(codigo CHECK (codigo >= 1 AND codigo <= 99999));
ALTER TABLE solicitud MODIFY(numero CHECK (numero >= 1 AND numero <= 99999));
ALTER TABLE oferta MODIFY(numero CHECK (numero >= 1 AND numero <= 99999));

--Tipoid
ALTER TABLE participante MODIFY(tid CHECK (tid IN ('CC','CE','NT')));

--TParticipante
ALTER TABLE participante MODIFY(tipo CHECK (tipo IN ('COM','VEN')));
ALTER TABLE solicitud MODIFY(tipo CHECK (tipo = 'COM'));
ALTER TABLE oferta MODIFY(tipo CHECK (tipo = 'VEN'));

--TCorreo
ALTER TABLE participante MODIFY(email CHECK (email LIKE '%@%' AND email NOT LIKE '%@' AND email NOT LIKE '@%' AND email NOT LIKE '%@%@%'));

--TMoneda
ALTER TABLE solicitud MODIFY(precio_min CHECK (precio_min > 0));
ALTER TABLE solicitud MODIFY(precio_max CHECK (precio_max > 0));
ALTER TABLE oferta MODIFY(precioOferta CHECK (precioOferta > 0));

--TEstado
ALTER TABLE factorMatch MODIFY(estado CHECK (estado IN ('PROCESO','ENMATCH','CERRADA')));

--TArea
ALTER TABLE area MODIFY(m_terreno CHECK (m_terreno >= 30.00 AND m_terreno <= 30000.00));
ALTER TABLE area MODIFY(m_construido CHECK (m_construido >= 30.00 AND m_construido <= 30000.00));

--TEstrato
ALTER TABLE estrato MODIFY(numero CHECK (numero > 0 AND numero <= 10));

--TTiempo
ALTER TABLE antiguedad MODIFY(tiempo CHECK (tiempo IN ('A1','A2','A3','A4')));

--TOferta
ALTER TABLE tipoOferta MODIFY(id CHECK (id IN ('V','A')));

--TPiso
ALTER TABLE tipoPiso MODIFY(nombre CHECK (nombre IN ('P1','P2','P3','P4','P5')));

--TCondicion
ALTER TABLE condicion MODIFY(id CHECK (id IN ('NUEVO','USADO')));
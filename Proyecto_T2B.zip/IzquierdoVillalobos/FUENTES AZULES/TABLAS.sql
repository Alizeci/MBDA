-----------------------------------
        /*CICLO 1: Tablas*/
-----------------------------------
CREATE TABLE participante
(
tid VARCHAR(2) NOT NULL,
nid NUMBER(15) NOT NULL,
tipo VARCHAR(3) NOT NULL,
nombre VARCHAR2(20) NOT NULL,
apellido VARCHAR2(20) NOT NULL,
email VARCHAR2(30)
);

CREATE TABLE telefono
(
tid VARCHAR(2) NOT NULL,
nid NUMBER(15) NOT NULL,
tipo VARCHAR(3) NOT NULL,
numero NUMBER(10) NOT NULL
);

CREATE TABLE solicitud
(
numero NUMBER(5) NOT NULL,
tid VARCHAR(2) NOT NULL,
nid NUMBER(15) NOT NULL,
tipo VARCHAR(3) NOT NULL,
fecha DATE NOT NULL,
precio_min NUMBER(9),
precio_max NUMBER(9) NOT NULL
);

CREATE TABLE oferta
(
numero NUMBER(5) NOT NULL,
tid VARCHAR(2) NOT NULL,
nid NUMBER(15) NOT NULL,
tipo VARCHAR(3) NOT NULL,
fecha DATE NOT NULL,
precioOferta NUMBER(9) NOT NULL,
negociable CHAR(1)
);

CREATE TABLE actualizacion
(
numero NUMBER(5) NOT NULL,
ultima_actualizacion DATE NOT NULL
);

CREATE TABLE factorMatch
(
codigo NUMBER(5) NOT NULL,
estado VARCHAR(7) NOT NULL
);

CREATE TABLE area
(
codigo NUMBER(5) NOT NULL,
m_terreno NUMBER(5,2) NOT NULL,
m_construido NUMBER(5,2)
);

CREATE TABLE estrato
(
codigo NUMBER(5) NOT NULL,
numero NUMBER(2) NOT NULL
);

CREATE TABLE inmueble
(
codigo NUMBER(5) NOT NULL,
nombre VARCHAR(10) NOT NULL,
descripcion VARCHAR2(50)
);

CREATE TABLE ubicacion
(
codigo NUMBER(5) NOT NULL,
departamento VARCHAR(12) NOT NULL,
ciudad VARCHAR(20) NOT NULL,
zona VARCHAR(20) NOT NULL,
barrio VARCHAR(20)
);

CREATE TABLE antiguedad
(
codigo NUMBER(5) NOT NULL,
tiempo VARCHAR(2)
);

CREATE TABLE tipoOferta
(
codigo NUMBER(5) NOT NULL,
id VARCHAR(1) NOT NULL
);

CREATE TABLE habitacion
(
codigo NUMBER(5) NOT NULL,
numero NUMBER(2) NOT NULL,
numero_baño NUMBER(2)
);

CREATE TABLE tipoPiso
(
codigo NUMBER(5) NOT NULL,
nombre VARCHAR(2),
numero NUMBER(2) NOT NULL,
descripcion VARCHAR(50)
);

CREATE TABLE condicion
(
codigo NUMBER(5) NOT NULL,
id VARCHAR(5) NOT NULL
);

CREATE TABLE extra
(
codigo NUMBER(5) NOT NULL,
descripcion VARCHAR2(50)
);

-----------------------------------
        /*CICLO 1: XTablas*/
-----------------------------------
DROP TABLE participante;
DROP TABLE telefono;
DROP TABLE solicitud;
DROP TABLE oferta;
DROP TABLE actualizacion;
DROP TABLE factorMatch;
DROP TABLE area;
DROP TABLE condicion;
DROP TABLE estrato;
DROP TABLE extra;
DROP TABLE habitacion;
DROP TABLE inmueble;
DROP TABLE tipoPiso;
DROP TABLE tipoOferta;
DROP TABLE ubicacion;
DROP TABLE antiguedad;
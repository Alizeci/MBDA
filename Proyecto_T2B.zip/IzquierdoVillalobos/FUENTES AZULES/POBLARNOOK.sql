
------------------------------------------------------------------------------------------------------------
                                       /*CICLO 1: PoblarNoOK*/
------------------------------------------------------------------------------------------------------------

--En oferta el participante con nid 35416363 es vendedor 'VEN'
INSERT INTO oferta VALUES (100,'CC',35416363,'COM',TO_DATE('2018/01/03','yyyy/mm/dd'),25000000,1);

--En solicitud el participante con nid 1075689854 no esta en participante
INSERT INTO solicitud VALUES (101,'CC',1075689854,'COM',TO_DATE('2018/01/03','yyyy/mm/dd'),18000000,20000000);

--En oferta ya existe el numero 102
INSERT INTO actualizacion VALUES (102,TO_DATE('2018/01/03','yyyy/mm/dd'));

--En tipoOferta el id debe ser una cadena 'V' o 'A'
INSERT INTO tipoOferta VALUES(101,23);

--No existe el registro de la oferta # 109 en factorMatch
INSERT INTO oferta VALUES (109,'CC',35416363,'V',TO_DATE('2018/01/03','yyyy/mm/dd'),25000000,1);

-----------------------------------
       /*CICLO 1: XPoblar*/
-----------------------------------
DELETE TABLE participante;
DELETE TABLE telefono;
DELETE TABLE solicitud;
DELETE TABLE oferta;
DELETE TABLE actualizacion;
DELETE TABLE factorMatch;
DELETE TABLE area;
DELETE TABLE condicion;
DELETE TABLE estrato;
DELETE TABLE extra;
DELETE TABLE habitacion;
DELETE TABLE inmueble;
DELETE TABLE tipoPiso;
DELETE TABLE tipoOferta;
DELETE TABLE ubicacion;
DELETE TABLE antiguedad;
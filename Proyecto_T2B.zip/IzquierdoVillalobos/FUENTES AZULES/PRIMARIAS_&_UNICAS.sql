-----------------------------------------------------------------
                  /*CICLO 1: Primarias & Unicas*/
-----------------------------------------------------------------

ALTER TABLE participante ADD 
(
CONSTRAINT PK_participante PRIMARY KEY (tid,nid,tipo),
CONSTRAINT UK_participante_email UNIQUE (email)
);

ALTER TABLE telefono ADD CONSTRAINT PK_telefono PRIMARY KEY (numero);
ALTER TABLE solicitud ADD CONSTRAINT PK_solicitud PRIMARY KEY (numero);
ALTER TABLE oferta ADD CONSTRAINT PK_oferta PRIMARY KEY (numero);
ALTER TABLE actualizacion ADD CONSTRAINT PK_actualizacion PRIMARY KEY (numero);
ALTER TABLE factorMatch ADD CONSTRAINT PK_factorMatch PRIMARY KEY (codigo);
ALTER TABLE area ADD CONSTRAINT PK_area PRIMARY KEY (codigo);
ALTER TABLE estrato ADD CONSTRAINT PK_estrato PRIMARY KEY (codigo);
ALTER TABLE inmueble ADD CONSTRAINT PK_inmueble PRIMARY KEY (codigo);
ALTER TABLE ubicacion ADD CONSTRAINT PK_ubicacion PRIMARY KEY (codigo);
ALTER TABLE antiguedad ADD CONSTRAINT PK_antiguedad PRIMARY KEY (codigo);
ALTER TABLE tipoOferta ADD CONSTRAINT PK_tipoOferta PRIMARY KEY (codigo);
ALTER TABLE habitacion ADD CONSTRAINT PK_habitacion PRIMARY KEY (codigo);
ALTER TABLE tipoPiso ADD CONSTRAINT PK_tipoPiso PRIMARY KEY (codigo);
ALTER TABLE condicion ADD CONSTRAINT PK_condicion PRIMARY KEY (codigo);
ALTER TABLE extra ADD CONSTRAINT PK_extra PRIMARY KEY (codigo);
